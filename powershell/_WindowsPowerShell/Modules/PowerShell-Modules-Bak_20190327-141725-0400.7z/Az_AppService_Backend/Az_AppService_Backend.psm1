#
# Example Call:
#
# Az_AppService_Backend `
# 	-SubscriptionID "xxxx" `
# 	-ResourceGroup "xxxx" `
# 	-AppServicePlanName "xxxx" `
# 	-KeyVault "xxxx" `
# 	-Epithet "xxxx" `
# 	-Vault_GitPullUrl443 ($az.secrets.git.clone_url_https) `
# 	-Vault_GitPullUrl22 ($az.secrets.git.clone_url_ssh) `
# 	-Vault_GitBranch ($az.secrets.git.branch) `
# 	-Vault_GitPullUser ($az.secrets.git.username) `
# 	-Vault_GitPullPass ($az.secrets.git.usertoken) `

function Az_AppService_Backend {
	Param(
		
		[Parameter(Mandatory=$true)]
		[String]$SubscriptionID	= "",
		
		[Parameter(Mandatory=$true)]
		[String]$ResourceGroup = "",

		[Parameter(Mandatory=$true)]
		[String]$AppServicePlanName = "",

		[String]$StartTimestamp = ((Get-Date -UFormat "%Y%m%d")+("-")+(Get-Date -UFormat "%H%M")),

		[String]$Epithet = (("bis-")+($StartTimestamp)),

		[String]$EpithetSql = $Epithet,

		[String]$Sku = "Developer",
		
		[String]$Location = "eastus",

		[Switch]$RunLocalServer,

		[String]$KeyVault_Sql = "bis-static-keyvault",
		[String]$Vault_SqlUser = "sql-adminuser",
		[String]$Vault_SqlPass = "sql-adminpass",

		[String]$KeyVault_Git = "bis-static-keyvault",
		[String]$Vault_GitPullUrl443 = "git-pull-url-https",
		[String]$Vault_GitPullUrl22 = "git-pull-url-ssh",
		[String]$Vault_GitBranch = "git-pull-branch",
		[String]$Vault_GitPullPass = "git-pull-token",
		[String]$Vault_GitPullUser = "git-pull-user",

		[String]$Vault_WebAppPortHttps = "webapp-dotnet-https-port",
		
		[String]$Vault_BackendProject = "webapp-backend-project"

	)
	
	# Fail-out if any required modules are not found within the current scope
	$RequireModule="BombOut"; 
	if (!(Get-Module ($RequireModule))) {
		Write-Host (("`n`nRequired Module not found: `"")+($RequireModule)+("`"`n`n"));
		Start-Sleep -Seconds 60;
		Exit 1;
	}

	# ------------------------------------------------------------- #

	$uris = @{};

	$uris.app = @{};
	$uris.app.swagger = "/swagger/index.html";

	$uris.scm = @{};
	$uris.scm.kudu = "/";
	$uris.scm.kudu_api = "/api/command";
	$uris.scm.kudu_procexp = "/ProcessExplorer";

	# ------------------------------------------------------------- #

	$az = @{};
	
	$az.account = @{};
	
	$az.keyvault = @{};

	$az.secrets = @{};

	$az.sql = @{};

	$az.webapp = @{};

	$az.webapp.config = @{};
	$az.webapp.cors = @{};
	$az.webapp.deployment = @{};
	$az.webapp.update = @{};

	$az.webapp.git = @{};
	$az.webapp.https = @{};
	$az.webapp.keyvault = @{};

	# ------------------------------------------------------------- #
	#### Web App (Backend)

	$az.epithet = ($Epithet);

	$az.subscription = ($SubscriptionID);

	$az.resource_group = ($ResourceGroup);

	$az.sql.server_name = (($EpithetSql)+("-sqlserver"));
	$az.sql.database_name = (($EpithetSql)+("-sqldb"));

	$az.keyvault.name = ($KeyVault);

	$az.webapp.plan = ($AppServicePlanName);

	$az.webapp.name = (($az.epithet)+("-api"));

	#
	# $az.webapp.fqdn = (($az.epithet)+(".azurewebsites.net"));
	#
	# $az.webapp.type = "Microsoft.Web/sites";
	#
	# $az.webapp.location = $Location;
	#
	# $az.webapp.properties = `
	# ConvertTo-Json `
	# 	-InputObject (('{"serverFarmId": "/subscriptions/')+($az.subscription)+('/resourceGroups/')+($az.resource_group)+('/providers/Microsoft.Web/serverfarms/')+($az.webapp.plan)+('"}')) `
	# 	-Depth 100;
	#
	# $az.webapp.sku = $Sku;
	#
	# $az.webapp.skuproperties = `
	# ConvertTo-Json `
	# 	-InputObject (('{"displayName": "Bonedge API", "apiRevision": "1", "description": null, "serviceUrl": "')+($az.webapp.fqdn)+('"}')) `
	# 	-Depth 100;
	#
	# $az.webapp.resourceType = "Microsoft.Insights/components";
	#

	$az.webapp.https_app = (("https://")+($az.webapp.name)+(".azurewebsites.net"));
	$az.webapp.https_scm = ($az.webapp.https_app).Replace(".azurewebsites.net", "scm.azurewebsites.net");

	$az.webapp.https.kudu = (($az.webapp.https_scm)+($uris.scm.kudu));
	$az.webapp.https.kudu_api = (($az.webapp.https_scm)+($uris.scm.kudu_api));
	$az.webapp.https.kudu_procexp = (($az.webapp.https_scm)+($uris.scm.kudu_procexp));
	$az.webapp.https.swagger = (($az.webapp.https_app)+($uris.app.swagger));

	$az.webapp.config.desc = "Web-App Config";
	$az.webapp.config.name = (($az.epithet) + ("-api-config"));
	$az.webapp.config.resource_group = ($az.resource_group);
	$az.webapp.config.connection_string_type = "SQLAzure";

	$az.webapp.git.branch = $null;
	$az.webapp.git.appType = "AspNetCore";
	$az.webapp.git.repoType = "vsts";
	$az.webapp.git.token = "some_token";

	$az.webapp.deployment.desc = "Kudu Git-Deployment Credentials";
	$az.webapp.deployment.user = (("bnl-")+(([Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes((Get-Random -SetSeed (Get-Random))))).Substring(0,20)));
	# Wait for a random amount of time so that we increase the millisecond gap between user & password string-generation (expert mode guessing)
	Start-Sleep -Milliseconds (Get-Random -Minimum (Get-Random -Minimum 50 -Maximum 499) -Maximum (Get-Random -Minimum 500 -Maximum 949));
	$az.webapp.deployment.pass = ((([Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes(("PASS!")+(Get-Random -SetSeed (Get-Random))))).Substring(0,20))+("aA1!"));
	$az.webapp.deployment.setuser = @{};	## Filled-in by:	[ az webapp deployment user set ... ]

	# ------------------------------------------------------------- #

	# Azure Subscription Info/Defaults
	$CommandDescription = "Requesting Subscription Information";
	Write-Host (("`n")+($CommandDescription)+("...`n"));

	$az.account.show = `
	az account show `
		| ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};

	# Bomb-out on errors
	BombOut `
		-ExitCode ($az.account.exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-MessageOnSuccessJSON ($az.account.show);

	# ------------------------------------------------------------- #

	# Get Secret [ Git Username ]
	$SecretName = $Vault_GitPullUser;
	$CommandDescription = ("Acquiring secret `"")+($SecretName)+("`"...");
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Git) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	# Get Secret [ Git Password ]
	$SecretName = $Vault_GitPullPass;
	$CommandDescription = (("Acquiring secret `"")+($SecretName)+("`"..."));
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Git) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	# Get Secret [ Git Url (HTTPS) ]
	$SecretName = $Vault_GitPullUrl443;
	$CommandDescription = (("Acquiring secret `"")+($SecretName)+("`"..."));
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Git) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	# Get Secret [ Git Branch ]
	$SecretName = $Vault_GitBranch;
	$CommandDescription = (("Acquiring secret `"")+($SecretName)+("`"..."));
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Git) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	# Sql Secret [ Sql Admin-User ]
	$SecretName = $Vault_SqlUser;
	$CommandDescription = (("Acquiring secret `"")+($SecretName)+("`"..."));
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Sql) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	# Sql Secret [ Sql Admin-Pass ]
	$SecretName = $Vault_SqlPass;
	$CommandDescription = (("Acquiring secret `"")+($SecretName)+("`"..."));
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Sql) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	# Sql Secret [ Web-App HTTPS Port ]
	$SecretName = $Vault_WebAppPortHttps;
	$CommandDescription = (("Acquiring secret `"")+($SecretName)+("`"..."));
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Git) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	# Sql Secret [ Backend Web-App Build-Path ]
	$SecretName = $Vault_BackendProject;
	$CommandDescription = (("Acquiring secret `"")+($SecretName)+("`"..."));
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Git) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	###--	Add credentials for local git deployment of Azure Web Apps (similar to GitHub's "Deploy Keys")
	###--		 Microsoft Docs, "az webapp deployment user" [ https://docs.microsoft.com/en-us/cli/azure/webapp/deployment/user?view=azure-cli-latest ]
	$CommandDescription = (("Creating ")+($az.webapp.deployment.desc)+(" for Web-App `"")+($az.webapp.name)+("`""));
	Write-Host (("`n")+($CommandDescription)+("...`n"));

	$az.webapp.deployment.setuser = `
	az webapp deployment user set `
		--user-name ($az.webapp.deployment.user) `
		--password ($az.webapp.deployment.pass) `
		| ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};

	# Bomb-out on errors
	BombOut -NoAzLogout `
		-ExitCode ($last_exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-MessageOnSuccessJSON ($az.webapp.deployment.setuser);

	# ------------------------------------------------------------- #

	###-- Create a web app

	$UseLocalGitRepo = $false;

	If ($UseLocalGitRepo -eq $true) {
		# Create a Web-App with local Git-deployment enabled

		$CommandDescription = (("Creating Web-App `"")+($az.webapp.name)+("`""));
		Write-Host (("`n")+($CommandDescription)+("...`n"));
		$az.webapp.create = `
		az webapp create `
			--resource-group ($az.resource_group) `
			--plan ($az.webapp.plan) `
			--name ($az.webapp.name) `
			--deployment-local-git `
			| ConvertFrom-Json;
		$last_exit_code = If($?){0}Else{1};

		# Bomb-out on errors
		BombOut -NoAzLogout `
			-ExitCode ($last_exit_code) `
			-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
			-MessageOnSuccessJSON ($az.webapp.create);

	} Else {
		# Create a Web-App with local Git-deployment disabled (then enable the Kudu build server)

		$CommandDescription = (("Creating Web-App `"")+($az.webapp.name)+("`""));
		Write-Host (("`n")+($CommandDescription)+("...`n"));
		$az.webapp.create = `
		az webapp create `
			--resource-group ($az.resource_group) `
			--plan ($az.webapp.plan) `
			--name ($az.webapp.name) `
			| ConvertFrom-Json;
		$last_exit_code = If($?){0}Else{1};

		# Bomb-out on errors
		BombOut -NoAzLogout `
			-ExitCode ($last_exit_code) `
			-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
			-MessageOnSuccessJSON ($az.webapp.create);

		# Enable Kudu build server
		$CommandDescription = ("Enabling Kudu build-server");
		Write-Host (("`n")+($CommandDescription)+("...`n"));
		$az.webapp.enable_kudu = `
		az webapp deployment source config-local-git `
			--name ($az.webapp.name) `
			--resource-group ($az.resource_group) `
			--subscription ($az.subscription) `
			| ConvertFrom-Json;
			# --verbose `
		$last_exit_code = If($?){0}Else{1};

		# Bomb-out on errors
		BombOut -NoAzLogout `
			-ExitCode ($last_exit_code) `
			-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
			-MessageOnSuccessJSON ($az.webapp.enable_kudu);
		
	}
	
	# ------------------------------------------------------------- #
	#		Web-App Update 
	#
	#			az webapp update ...
	#			--> https://docs.microsoft.com/en-us/cli/azure/webapp?view=azure-cli-latest#az-webapp-update
	#

	$CommandDescription = ("Updating Web-App");
	Write-Host (("`n")+($CommandDescription)+("...`n"));
	
	$az.webapp.update = `
	az webapp update `
		--name ($az.webapp.name) `
		--resource-group ($az.resource_group) `
		--subscription ($az.subscription) `
		--client-affinity-enabled true `
		--https-only true `
		| ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};

	# Bomb-out on errors
	BombOut `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-ExitCode ($last_exit_code) `
		-NoAzLogout;

	# ------------------------------------------------------------- #

	# Git Schema
	$git = @{};
	$git.local = @{};
	$git.remote = @{};

		# Git Source-Remote (to push-to)
		$git.remote.source = @{};
		$git.remote.source.url = ($az.secrets[$Vault_GitPullUrl443]);
		$git.remote.source.branch = ($az.secrets[$Vault_GitBranch]);
		$git.remote.source.reponame = [System.IO.Path]::GetFileNameWithoutExtension(([System.Uri]$git.remote.source.url).Segments[-1]);
		$git.remote.source.ref_uid = (("src")+(Get-Date -UFormat "%Y%m%d%H%M%S")+("repo"));

		# Git Destination-Remote (to push-to)
		$git.remote.destination = @{};
		$git.remote.destination.url = (("https://")+($az.webapp.name)+(".scm.azurewebsites.net/")+($az.webapp.name)+(".git"));
		$git.remote.destination.fqdn = ([System.Uri]($git.remote.destination.url)).Host;
		$git.remote.destination.reponame = [System.IO.Path]::GetFileNameWithoutExtension(([System.Uri]$git.remote.destination.url).Segments[-1]);
		$git.remote.destination.ref_uid = (("webapp")+(Get-Date -UFormat "%Y%m%d%H%M%S"));
		$git.remote.destination.branch = "master";
		$git.remote.destination.commit_msg = (("Instantiating WebApp [ ")+($az.epithet)+(" ] "));
		
		# Build the username & token into one single url-request to push-to (which deploys into the web-app)
		$git.remote.destination.inline_creds_url = (("https://")+($az.webapp.deployment.user)+(":")+($az.webapp.deployment.pass)+("@")+($az.webapp.name)+(".scm.azurewebsites.net/")+($az.webapp.name)+(".git"));

		# Git Schema - Local
		$git.local.desc = "Web App - .NET Core";
		$git.local.parent_dir = (($Home)+("/git"));
		$git.local.reponame = ($git.remote.source.reponame);
		$git.local.work_tree = (($git.local.parent_dir)+("/")+($git.local.reponame));
	
	# Make sure the parent directory to the git-repo exists
	if ((Test-Path -Path ($git.local.parent_dir)) -eq $false) {
		Write-Host (("`nTask - Creating git parent-directory at `"")+($git.local.parent_dir)+("`""));
		New-Item -ItemType "Directory" -Path ($git.local.parent_dir);
	}

	# ------------------------------------------------------------- #

	$dotnet = @{};
	$dotnet.publish = @{};

	$dotnet.publish.reponame = ($git.local.reponame);
	
	$dotnet.publish.parent_abs = ($git.local.work_tree);

	$dotnet.publish.project_rel = ($az.secrets[$Vault_BackendProject]);
	$dotnet.publish.project_abs = (($dotnet.publish.parent_abs)+("/")+($dotnet.publish.project_rel));

	$dotnet.publish.csproj_rel = (($dotnet.publish.project_rel)+("/")+($dotnet.publish.project_rel)+(".csproj"));
	$dotnet.publish.csproj_abs = (($dotnet.publish.parent_abs)+("/")+($dotnet.publish.csproj_rel));
	
	# $dotnet.publish.configuration = "Debug";
	# $dotnet.publish.configuration = "Production";

	$dotnet.publish.output = (($dotnet.publish.parent_abs)+("/published_")+(Get-Date -UFormat "%Y%m%d-%H%M%S"));
	
	# ------------------------------------------------------------- #

	###-- Create SQL Server Firewall Whitelist for the WebApp's IPv4
	
	$CommandDescription = ("Adding WebApp's IPv4 to SQL Server Firewall's Whitelist");
	Write-Host (("`n")+($CommandDescription)+("...`n"));

	$git.remote.destination.wan_ipv4 = `
		ResolveIPv4 `
		-Url ($git.remote.destination.url);
	
	$az.sql.firewall_allow_webapp_ipv4 = `
	az sql server firewall-rule create `
		--subscription ($az.subscription) `
		--resource-group ($az.resource_group) `
		--server ($az.sql.server_name) `
		--name (("Allow_IPv4_")+($git.remote.destination.wan_ipv4)) `
		--start-ip-address ($git.remote.destination.wan_ipv4) `
		--end-ip-address ($git.remote.destination.wan_ipv4) `
		| ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};

	# Bomb-out on errors
	BombOut -NoAzLogout `
		-ExitCode ($last_exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-MessageOnSuccessJSON ($az.sql.firewall_allow_webapp_ipv4);

	# ------------------------------------------------------------- #
	#		Web-App Configuration
	#
	#			az webapp config appsettings ...
	#			--> https://docs.microsoft.com/en-us/cli/azure/webapp/config?view=azure-cli-latest#az-webapp-config-set
	#

	$CommandDescription = (("Setting [ Web-App Configuration ] for `"")+($az.webapp.name)+("`""));
	Write-Host (("`n")+($CommandDescription)+("...`n"));

	$az.webapp.config.set = `
	az webapp config set `
		--name ($az.webapp.name) `
		--resource-group ($az.resource_group) `
		--subscription ($az.subscription) `
		--http20-enabled "false" `
		--min-tls-version "1.2" `
		--ftps-state "FtpsOnly" `
		| ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};

	# Bomb-out on errors
	BombOut `
		-NoAzLogout `
		-ExitCode ($last_exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-MessageOnSuccessJSON ($az.webapp.config.set);

	# ------------------------------------------------------------- #
	#		Web-App CORS Configuration
	#
	#			az webapp cors add ...
	#			--> https://docs.microsoft.com/en-us/cli/azure/webapp/cors?view=azure-cli-latest#az-webapp-cors-add
	#

	<#

	$CommandDescription = (("Setting [ Web-App Configuratio ] for `"")+($az.webapp.name)+("`""));
	Write-Host (("`n")+($CommandDescription)+("...`n"));

	$az.webapp.cors.add = `
	az webapp cors add  `
		--name ($az.webapp.name) `
		--resource-group ($az.resource_group) `
		--subscription ($az.subscription) `
		--allowed-origins https://myapps.com `
	 ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};

	# Bomb-out on errors
	BombOut `
		-NoAzLogout `
		-ExitCode ($last_exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-MessageOnSuccessJSON ($az.webapp.config.set);

	#>

	# ------------------------------------------------------------- #

	###-- Application Settings (secrets)
	#
	#	az webapp config appsettings
	#	 |-->https://docs.microsoft.com/en-us/cli/azure/webapp/config/appsettings?view=azure-cli-latest
	#
	# Configurable settings
	#	 |--> https://github.com/projectkudu/kudu/wiki/Configurable-settings
	#
	# docs.microsoft.com - "To customize your deployment, include a .deployment file in the repository root"
	#	 |-->https://docs.microsoft.com/en-us/azure/app-service/deploy-local-git
	#

	$CommandDescription = (("Configuring [ Application Settings ] for Web-App `"")+($az.webapp.name)+("`""));
	Write-Host (("`n")+($CommandDescription)+("...`n"));

	$az.webapp.appSettings = @{};
	$az.webapp.appSettings["MobileAppsManagement_EXTENSION_VERSION"] = "latest";
	$az.webapp.appSettings["MSDEPLOY_RENAME_LOCKED_FILES"] = "1";
	$az.webapp.appSettings["WEBSITE_RUN_FROM_PACKAGE"] = "0";

	$last_exit_code = 0;
	ForEach ($appSetting In (($az.webapp.appSettings).GetEnumerator())) {
		
		$az.webapp.appSettingsSet = `
		az webapp config appsettings set `
			--name ($az.webapp.name) `
			--resource-group ($az.resource_group) `
			--subscription ($az.subscription) `
			--settings (($appSetting.Name)+("=")+($appSetting.Value)) `
			| ConvertFrom-Json;
			
		$last_exit_code += If($?){0}Else{1};

	}

	# Bomb-out on errors
	BombOut -NoAzLogout `
		-ExitCode ($last_exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-MessageOnSuccessJSON ($az.webapp.appSettingsSet);

	# ------------------------------------------------------------- #
	
	###-- [ Connection Strings (SQL-DB) ]

	$CommandDescription = (("Configuring [ Connection String(s) ] for Web-App `"")+($az.webapp.name)+("`""));
	Write-Host (("`n")+($CommandDescription)+("...`n"));
	$az.webapp.connectionStrings = @{};
	$az.webapp.connectionStrings = ( `
		"DefaultConnection='" + `
			("Server=tcp:")+($az.sql.server_name)+(".database.windows.net,1433;") + `
			("Initial Catalog=")+($az.sql.database_name)+(";") + `
			("Persist Security Info=False;") + `
			("User ID=")+($az.secrets[$Vault_SqlUser])+(";") + `
			("Password=")+($az.secrets[$Vault_SqlPass])+(";") + `
			("MultipleActiveResultSets=False;") + `
			("Encrypt=True;") + `
			("TrustServerCertificate=False;") + `
			("Connection Timeout=60;") + `
		"'" `
	);
	
	# $az.webapp.connectionStringsJSON = (ConvertTo-Json -InputObject ($az.webapp.connectionStrings) -Depth 100 -Compress);

	$az.webapp.connectionStringsSet = `
	az webapp config connection-string set `
		--name ($az.webapp.name) `
		--resource-group ($az.webapp.config.resource_group) `
		--connection-string-type ($az.webapp.config.connection_string_type) `
		--settings ($az.webapp.connectionStrings) `
		| ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};

		# --settings ($az.webapp.connectionStringsJSON) `

	# Bomb-out on errors
	BombOut -NoAzLogout `
		-ExitCode ($last_exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-MessageOnSuccessJSON ($az.webapp.connectionStringsSet);

	# ------------------------------------------------------------- #

	<#
	$CommandDescription = (("Configuring [ Application Settings ] for Web-App `"")+($az.webapp.name)+("`""));
	Write-Host (("`n")+($CommandDescription)+("...`n"));
	
	$BuildSetting = (("PROJECT=")+($dotnet.publish.csproj_rel));
	$ConfigWebapp = az webapp config appsettings set --name ($az.webapp.name) --resource-group ($az.resource_group) --subscription ($az.subscription) --settings ($BuildSetting) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};

	$BuildSetting = ("MobileAppsManagement_EXTENSION_VERSION=latest");
	$ConfigWebapp = az webapp config appsettings set --name ($az.webapp.name) --resource-group ($az.resource_group) --subscription ($az.subscription) --settings ($BuildSetting) | ConvertFrom-Json;
	$last_exit_code += If($?){0}Else{1};

	$BuildSetting = ("MSDEPLOY_RENAME_LOCKED_FILES=1");
	$ConfigWebapp = az webapp config appsettings set --name ($az.webapp.name) --resource-group ($az.resource_group) --subscription ($az.subscription) --settings ($BuildSetting) | ConvertFrom-Json;
	$last_exit_code += If($?){0}Else{1};
	# Bomb-out on errors
	BombOut -NoAzLogout `
		-ExitCode ($last_exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-MessageOnSuccessJSON ($az.webapp.appSettingsSet);
	#>

	# ------------------------------------------------------------- #

	# Git Pull from the Source-Repo
	
	# Build the username & token into one single url-request to pull from the git-repo with
	$git.remote.source.inline_creds_url = (("https://")+($az.secrets[$Vault_GitPullUser])+(":")+($az.secrets[$Vault_GitPullPass])+("@")+(($git.remote.source.url).Replace("https://","")));

	Set-Location -Path ($git.local.parent_dir);

	## Clone the Source-Repo
	$git.remote.destination.clone = `
	GitCloneRepo `
		-Url ($git.remote.source.inline_creds_url) `
		-LocalDirname ($git.local.parent_dir) `
		-SkipResolveUrl `
		-Quiet;
	
	# ------------------------------------------------------------- #

	$CommandDescription = ("Installing Windows Pre-Required DLL Runtimes");
	Write-Host (("`n")+($CommandDescription)+("...`n"));

	# HOTFIX - Install addtional required packages (required to be installed before dotnet publish runs)
	$dotnet.packages = @{};

	# Microsoft.AspNetCore
	$dotnet.packages["Microsoft.AspNetCore.Identity"] = "2.1.6";
	$dotnet.packages["Microsoft.AspNetCore.Identity.EntityFrameworkCore"] = "2.1.6";
	# $dotnet.packages["Microsoft.AspNetCore.Identity.UI"] = "2.1.6";

	# Microsoft.Extensions
	$dotnet.packages["Microsoft.Extensions.Identity.Core"] = "2.1.6";
	$dotnet.packages["Microsoft.Extensions.Identity.Stores"] = "2.1.6";

	Set-Location -Path ($dotnet.publish.project_abs);
	ForEach ($RequiredPackage In (($dotnet.packages).GetEnumerator())) {
		
		ForEach ($EachMatchedDir In ((Get-ChildItem -Directory -Name -Path ($git.local.work_tree) -Include (($dotnet.publish.reponame)+("*"))).GetEnumerator())) {
			Set-Location -Path (($git.local.work_tree)+("/")+($EachMatchedDir));

			$CommandDescription = (("Installing: `"")+($RequiredPackage.Name)+(".dll`",  Version `"")+($RequiredPackage.Value)+("`" into `"")+($EachMatchedDir)+("`""));
			Write-Host ($CommandDescription);

			dotnet add package ($RequiredPackage.Name) --version ($RequiredPackage.Value) | Out-Null;

		}
	}

	# ------------------------------------------------------------- #
	
	# Push Codebase to Web-App (caught by the Kudu build server running in Azure Web-Apps)

	# $PublishBeforePush = $false;
	$PublishBeforePush = $true;

	Set-Location -Path ($git.local.work_tree);
	git config --global user.email ($az.account.show.user.name);
	git config --global user.name ($az.account.show.user.name);
		
	# -------------------------------------------------------------------------------------------------------------------------- #
	If ($PublishBeforePush -eq $true) {

		# Publish the Web-App
		Set-Location -Path ($dotnet.publish.parent_abs);

		# dotnet publish  <-- automatically performs dotnet restore & dotnet build, unless specified otherwise
		
		### COMPILE STEP
		dotnet publish ($dotnet.publish.csproj_abs) --output ($dotnet.publish.output); # Note: output directory must be an absolute path

		# Setup Repo inside of the compiled code directory (push only those files)
		Set-Location -Path ($dotnet.publish.output);

		git init;
		git add .;
		git commit -m ($git.remote.destination.commit_msg);
		git remote add origin ($git.remote.destination.inline_creds_url);

		# Set a default Project build-path for the app-service
		# $az.webapp.appSettingsSet = `
		# az webapp config appsettings set `
		# 	--name ($az.webapp.name) `
		# 	--resource-group ($az.resource_group) `
		# 	--subscription ($az.subscription) `
		# 	--settings (("COMMAND='dotnet .\BonEdge.Api.dll'")) `
		# 	| ConvertFrom-Json;
		
		$CommandDescription = (("Pushing Compiled Code to Web-App `"")+($az.webapp.name)+("`"'s Kudu Build-Server"));
		Write-Host (("`n")+($CommandDescription)+("...`n"));

		git push origin master;

	} Else { # -------------------------------------------------------------------------------------------------------------------------- #

		# Redirect current code-repo so we can push to separate remote git-repo

		# Set a default Project build-path for the app-service
		$az.webapp.appSettingsSet = `
		az webapp config appsettings set `
			--name ($az.webapp.name) `
			--resource-group ($az.resource_group) `
			--subscription ($az.subscription) `
			--settings (("PROJECT=")+($dotnet.publish.csproj_rel)) `
			| ConvertFrom-Json;

		Set-Location -Path ($git.local.work_tree);
		
		git remote add ($git.remote.destination.ref_uid) ($git.remote.destination.inline_creds_url);
		git add -A;
		git commit -m ($git.remote.destination.commit_msg);

		$CommandDescription = (("Pushing Full Repo to Web-App `"")+($az.webapp.name)+("`"'s Kudu Build-Server"));
		Write-Host (("`n")+($CommandDescription)+("...`n"));
		
		### COMPILE STEP
		git push ($git.remote.destination.ref_uid) ($git.remote.destination.branch);
		
	}
	# -------------------------------------------------------------------------------------------------------------------------- #
	
	### Local Server Spinup

	If ($PSBoundParameters.ContainsKey('RunLocalServer') -and $false) {
		### Spin-Up & Navigate to the Service (running locally)

		# Localhost Service-URLs
		$localhost = @{};
		$localhost.https = @{};
		$localhost.https.app = (("https://localhost:")+($az.secrets[$Vault_WebAppPortHttps]));
		$localhost.https.swagger = (($localhost.https.app)+($uris.app.swagger));

		### Run a secondary powershell instance temporarily (so we can still use the first)
		Write-Host (("`nSpinning-Up server: ") + ($localhost.https.swagger) + ("`n"));

		Set-Location -Path (($git.local.work_tree)+("/")+($az.secrets[$Vault_BackendProject]));

		# If ((EnsureCommandExists -Name ("Start") -Quiet -ContinueOnErrors) -eq 0) {
		# 	$Revertable_ErrorActionPreference = $ErrorActionPreference;
		# 	$ErrorActionPreference = 'SilentlyContinue';
		# 		$PowerShell_SourceExe = (Get-Command -Name "powershell.exe").Source;
		# 	$ErrorActionPreference = $Revertable_ErrorActionPreference;
		# 	Start "${PowerShell_SourceExe}" "Set-Location -Path '$pwd'; dotnet run; Start-Sleep -Seconds 600;";
		# }

		### Wait for Swagger to be reponsive
		$CurrentSwaggerStatusCode = ((Invoke-WebRequest -UseBasicParsing -Method HEAD -Uri ($localhost.https.swagger)).StatusCode);
		Write-Host (("`nStatus-Code for Swagger is currently [")+($CurrentSwaggerStatusCode)+("]"));
		While (((Invoke-WebRequest -UseBasicParsing -Method HEAD -Uri ($localhost.https.swagger)).StatusCode) -ne (200)) {
			$CurrentSwaggerStatusCode = ((Invoke-WebRequest -UseBasicParsing -Method HEAD -Uri ($localhost.https.swagger)).StatusCode);
			Write-Host (("`nStatus-Code for Swagger is currently [")+($CurrentSwaggerStatusCode)+("]"));
			Start-Sleep -Milliseconds 500;
		}

		### Browse to Swagger once-responsive
		# If ((EnsureCommandExists -Name ("Start") -Quiet -ContinueOnErrors) -eq 0) {
		# 	Start ($localhost.https.swagger);
		# }

	}

	# ------------------------------------------------------------- #

	Return $az.webapp.create;

}

Export-ModuleMember -Function "Az_AppService_Backend";