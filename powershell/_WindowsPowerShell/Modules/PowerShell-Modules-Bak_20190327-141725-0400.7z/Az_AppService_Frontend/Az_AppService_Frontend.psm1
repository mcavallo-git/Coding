#### Az_AppService_Backend -SubscriptionID "BonEDGE-BIS" -ResourceGroup "bis-sandbox-rg";
function Az_AppService_Frontend {
	Param(

		[Parameter(Mandatory=$true)]
		[String]$SubscriptionID	= "",
		
		[Parameter(Mandatory=$true)]
		[String]$ResourceGroup = "",

		[Parameter(Mandatory=$true)]
		[String]$AppServicePlanName = "",

		[String]$Epithet = (("bis-") + (Get-Date -UFormat "%Y%m%d%H%M%S")),

		[String]$Sku = "Developer",
		
		[String]$Location = "eastus",

		[Switch]$RunLocalServer,

		[String]$KeyVault_Git = "bis-static-keyvault",
		[String]$Vault_GitPullUrl443 = "git-pull-url-https",
		[String]$Vault_GitPullUrl22 = "git-pull-url-ssh",
		[String]$Vault_GitBranch = "git-pull-branch",
		[String]$Vault_GitPullPass = "git-pull-token",
		[String]$Vault_GitPullUser = "git-pull-user",

		[String]$Vault_WebAppPortHttps = "webapp-dotnet-https-port",
		[String]$Vault_WebAppPortHttp = "webapp-dotnet-http-port",
		
		[String]$Vault_BackendProject = "webapp-backend-project",
		[String]$Vault_FrontendProject = "webapp-frontend-project",
		[String]$Vault_FrontendProject_Angular = "git-webapp-buildpath-frontend-angular"
	)

	# Fail-out if any required modules are not found within the current scope
	$RequireModule="BombOut"; 
	if (!(Get-Module ($RequireModule))) {
		Write-Host (("`n`nRequired Module not found: `"")+($RequireModule)+("`"`n`n"));
		Start-Sleep -Seconds 60;
		Exit 1;
	}

	# ------------------------------------------------------------- #

	$uris = @{};

	$uris.app = @{};
	$uris.app.swagger = "/swagger/index.html";

	$uris.scm = @{};
	$uris.scm.kudu = "/";
	$uris.scm.kudu_web = "/web/command";
	$uris.scm.kudu_procexp = "/ProcessExplorer";

	# ------------------------------------------------------------- #

	$az = @{};
	
	$az.account = @{};
	
	$az.keyvault = @{};

	$az.secrets = @{};

	$az.sql = @{};

	$az.webapp = @{};

	$az.webapp.config = @{};
	$az.webapp.deployment = @{};
	$az.webapp.git = @{};
	$az.webapp.keyvault = @{};
	$az.webapp.https = @{};

	# ------------------------------------------------------------- #
	#### Web App (Backend)

	$az.epithet = ($Epithet);

	$az.subscription = ($SubscriptionID);

	$az.resource_group = ($ResourceGroup);

	$az.keyvault.name = ($KeyVault_Git);

	$az.webapp.name = (($az.epithet)+("-web"));

	$az.webapp.plan = ($AppServicePlanName);

	# $az.webapp.fqdn = (($az.epithet)+(".azurewebsites.net"));
	#
	# $az.webapp.type = "Microsoft.Web/sites";
	#
	# $az.webapp.location = $Location;
	#
	# $az.webapp.properties = `
	# ConvertTo-Json `
	# 	-InputObject (('{"serverFarmId": "/subscriptions/')+($az.subscription)+('/resourceGroups/')+($az.resource_group)+('/providers/Microsoft.Web/serverfarms/')+($az.webapp.plan)+('"}')) `
	# 	-Depth 100;
	#
	# $az.webapp.sku = $Sku;
	#
	# $az.webapp.skuproperties = `
	# ConvertTo-Json `
	# 	-InputObject (('{"displayName": "Bonedge API", "apiRevision": "1", "description": null, "serviceUrl": "')+($az.webapp.fqdn)+('"}')) `
	# 	-Depth 100;
	#
	# $az.webapp.resourceType = "Microsoft.Insights/components";
	#

	$az.webapp.https_app = (("https://")+($az.webapp.name)+(".azurewebsites.net"));
	$az.webapp.https_scm = ($az.webapp.https_app).Replace(".azurewebsites.net", "scm.azurewebsites.net");

	$az.webapp.https.kudu = (($az.webapp.https_scm)+($uris.scm.kudu));
	$az.webapp.https.kudu_web = (($az.webapp.https_scm)+($uris.scm.kudu_web));
	$az.webapp.https.kudu_procexp = (($az.webapp.https_scm)+($uris.scm.kudu_procexp));

	$az.webapp.config.desc = "Web-App Config";
	$az.webapp.config.name = (($az.epithet) + ("-web-config"));
	$az.webapp.config.resource_group = ($az.resource_group);
  $az.webapp.config.connection_string_type = "SQLAzure";
  $az.webapp.config.appSettings_string = "WEBSITE_NODE_DEFAULT_VERSION=0.10.40";
  
	$az.webapp.git.branch = $null;
	
	$az.webapp.git.appType = "AspNetCore";
	$az.webapp.git.repoType = "vsts";
	$az.webapp.git.token = "some_token";

	$az.webapp.deployment.desc = "Web-App Deployment Credentials";
	$az.webapp.deployment.user = (("bnl-")+(([Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes((Get-Random -SetSeed (Get-Random))))).Substring(0,20)));
	# Wait for a random amount of time so that we increase the millisecond gap between user & password string-generation (expert mode guessing)
	Start-Sleep -Milliseconds (Get-Random -Minimum (Get-Random -Minimum 50 -Maximum 499) -Maximum (Get-Random -Minimum 500 -Maximum 949));
	$az.webapp.deployment.pass = ((([Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes(("PASS!")+(Get-Random -SetSeed (Get-Random))))).Substring(0,20))+("aA1!"));
	$az.webapp.deployment.setuser = @{};	## Filled-in by:	[ az webapp deployment user set ... ]

	# ------------------------------------------------------------- #

	# Azure Subscription Info/Defaults
	$CommandDescription = "Requesting Subscription Information";
	Write-Host (("`n")+($CommandDescription)+("...`n"));

	$az.account.show = `
	az account show `
		| ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};

	# Bomb-out on errors
	BombOut `
		-ExitCode ($az.account.exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-MessageOnSuccessJSON ($az.account.show);

	# ------------------------------------------------------------- #

	# Get Secret [ Git Username ]
	$SecretName = $Vault_GitPullUser;
	$CommandDescription = ("Acquiring secret `"")+($SecretName)+("`"...");
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Git) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	# Get Secret [ Git Password ]
	$SecretName = $Vault_GitPullPass;
	$CommandDescription = (("Acquiring secret `"")+($SecretName)+("`"..."));
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Git) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	# Get Secret [ Git Url (HTTPS) ]
	$SecretName = $Vault_GitPullUrl443;
	$CommandDescription = (("Acquiring secret `"")+($SecretName)+("`"..."));
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Git) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	# Get Secret [ Git Branch ]
	$SecretName = $Vault_GitBranch;
	$CommandDescription = (("Acquiring secret `"")+($SecretName)+("`"..."));
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Git) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	# Sql Secret [ Web-App HTTPS Port ]
	$SecretName = $Vault_WebAppPortHttps;
	$CommandDescription = (("Acquiring secret `"")+($SecretName)+("`"..."));
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Git) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	# Sql Secret [ Frontend Web-App Build-Path ]
	$SecretName = $Vault_FrontendProject;
	$CommandDescription = (("Acquiring secret `"")+($SecretName)+("`"..."));
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Git) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #

	# Sql Secret [ Frontend Web-App Build-Path ]
	$SecretName = $Vault_FrontendProject_Angular;
	$CommandDescription = (("Acquiring secret `"")+($SecretName)+("`"..."));
	$az.secrets[$SecretName] = az keyvault secret show --subscription ($az.subscription) --vault-name ($KeyVault_Git) --name ($SecretName) | ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};
	BombOut -NoAzLogout -ExitCode ($last_exit_code) -MessageOnError (('Error while [') + ($CommandDescription) + (']')) -MessageOnSuccess (("Acquired secret `"")+($SecretName)+("`"")); 

	$az.secrets[$SecretName] = $az.secrets[$SecretName].value;

	# ------------------------------------------------------------- #


	###--	Add credentials for local git deployment of Azure Web Apps (similar to GitHub's "Deploy Keys")
	###--		 Microsoft Docs, "az webapp deployment user" [ https://docs.microsoft.com/en-us/cli/azure/webapp/deployment/user?view=azure-cli-latest ]
	$CommandDescription = (("Creating ")+($az.webapp.deployment.desc)+(" w/ username `"")+($az.webapp.deployment.user)+("`""));
	Write-Host (("`n")+($CommandDescription)+("...`n"));

	$az.webapp.deployment.setuser = `
	az webapp deployment user set `
		--user-name ($az.webapp.deployment.user) `
		--password ($az.webapp.deployment.pass) `
		| ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};

	# Bomb-out on errors
	BombOut -NoAzLogout `
		-ExitCode ($last_exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-MessageOnSuccessJSON ($az.webapp.deployment.setuser);

	# ------------------------------------------------------------- #

	###-- Create a web app

	$UseLocalGitRepo = $false;

	If ($UseLocalGitRepo -eq $true) {
		# Create a Web-App with local Git-deployment enabled

		$CommandDescription = (("Creating web-app `"")+($az.webapp.name)+("`""));
		Write-Host (("`n")+($CommandDescription)+("...`n"));
		$az.webapp.create = `
		az webapp create `
			--resource-group ($az.resource_group) `
			--plan ($az.webapp.plan) `
			--name ($az.webapp.name) `
			--deployment-local-git `
			| ConvertFrom-Json;
		$last_exit_code = If($?){0}Else{1};

		# Bomb-out on errors
		BombOut -NoAzLogout `
			-ExitCode ($last_exit_code) `
			-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
			-MessageOnSuccessJSON ($az.webapp.create);

	} Else {
		# Create a Web-App with local Git-deployment disabled (then enable the Kudu build server)

		$CommandDescription = (("Creating web-app `"")+($az.webapp.name)+("`""));
		Write-Host (("`n")+($CommandDescription)+("...`n"));
		$az.webapp.create = `
		az webapp create `
			--resource-group ($az.resource_group) `
			--plan ($az.webapp.plan) `
			--name ($az.webapp.name) `
			| ConvertFrom-Json;
		$last_exit_code = If($?){0}Else{1};

		# Bomb-out on errors
		BombOut -NoAzLogout `
			-ExitCode ($last_exit_code) `
			-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
			-MessageOnSuccessJSON ($az.webapp.create);

		# Enable Kudu build server
		$CommandDescription = ("Enabling Kudu build-server");
		Write-Host (("`n")+($CommandDescription)+("...`n"));
		$az.webapp.enable_kudu = `
		az webapp deployment `
			source config-local-git `
			--name ($az.webapp.name) `
			--resource-group ($az.resource_group) `
			--subscription ($az.subscription) `
			| ConvertFrom-Json;
			# --verbose `
		$last_exit_code = If($?){0}Else{1};

		# Bomb-out on errors
		BombOut -NoAzLogout `
			-ExitCode ($last_exit_code) `
			-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
			-MessageOnSuccessJSON ($az.webapp.enable_kudu);
		
	}


  # $CommandDescription = ("Enabling App Settings for NODE Version");
	# 	Write-Host (("`n")+($CommandDescription)+("...`n"));
	# 	$az.webapp.config.appSettings = `
	# 	az webapp config appsettings set `
	# 		--name ($az.webapp.name) `
	# 		--resource-group ($az.resource_group) `
  #     --subscription ($az.subscription) `
  #     --settings ($az.webapp.config.appSettings_string) `
	# 		| ConvertFrom-Json;
	# 		# --verbose `
	# 	$last_exit_code = If($?){0}Else{1};

	# 	# Bomb-out on errors
	# 	BombOut -NoAzLogout `
	# 		-ExitCode ($last_exit_code) `
	# 		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
	# 		-MessageOnSuccessJSON ($az.webapp.config.appSettings);
  # ------------------------------------------------------------- #
  $az.webapp.config.connectionStringName = (`
			("DefaultEndpointsProtocol=https;") + `
			("AccountName=[myaccount];") + `
			("AccountKey=[mykey];") `
  );
  
  $az.webapp.config.connectionDashboard = (("AzureWebJobsDashboard=")+($az.webapp.config.connectionStringName | ConvertTo-Json));
  $az.webapp.config.connectionStorage = (("AzureWebJobsStorage=")+($az.webapp.config.connectionStringName | ConvertTo-Json));

	$az.webapp.config_connection_dashboard = `
	az webapp config connection-string set `
		--name ($az.webapp.name) `
		--resource-group ($az.webapp.config.resource_group) `
		--connection-string-type ($az.webapp.config.connection_string_type) `
		--settings ($az.webapp.config.connectionDashboard) `
		| ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};

	# Bomb-out on errors
	BombOut -NoAzLogout `
		-ExitCode ($last_exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
    -MessageOnSuccessJSON ($az.webapp.config_connection_dashboard);


    $az.webapp.config_connection_storage = `
    az webapp config connection-string set `
      --name ($az.webapp.name) `
      --resource-group ($az.webapp.config.resource_group) `
      --connection-string-type ($az.webapp.config.connection_string_type) `
      --settings ($az.webapp.config.connectionStorage) `
      | ConvertFrom-Json;
    $last_exit_code = If($?){0}Else{1};
  
    # Bomb-out on errors
    BombOut -NoAzLogout `
      -ExitCode ($last_exit_code) `
      -MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
      -MessageOnSuccessJSON ($az.webapp.config_connection_storage);
    # ------------------------------------------------------------- #

	# Git Schema
	$git = @{};
	$git.local = @{};
	$git.remote = @{};

		# Git Source-Remote (to push-to)
		$git.remote.source = @{};
		$git.remote.source.url = ($az.secrets[$Vault_GitPullUrl443]);
		$git.remote.source.branch = ($az.secrets[$Vault_GitBranch]);
		$git.remote.source.reponame = [System.IO.Path]::GetFileNameWithoutExtension(([System.Uri]$git.remote.source.url).Segments[-1]);
		$git.remote.source.ref_uid = (("src")+(Get-Date -UFormat "%Y%m%d%H%M%S")+("repo"));

		# Git Destination-Remote (to push-to)
		$git.remote.destination = @{};
		$git.remote.destination.url = (("https://")+($az.webapp.name)+(".scm.azurewebsites.net/")+($az.webapp.name)+(".git"));
		$git.remote.destination.fqdn = ([System.Uri]($git.remote.destination.url)).Host;
		$git.remote.destination.reponame = [System.IO.Path]::GetFileNameWithoutExtension(([System.Uri]$git.remote.destination.url).Segments[-1]);
		$git.remote.destination.ref_uid = (("webapp")+(Get-Date -UFormat "%Y%m%d%H%M%S"));
		$git.remote.destination.branch = "master";
		$git.remote.destination.commit_msg = (("Instantiating WebApp [ ")+($az.epithet)+(" ] "));
		
		# Build the username & token into one single url-request to push-to (which deploys into the web-app)
		$git.remote.destination.inline_creds_url = (("https://")+($az.webapp.deployment.user)+(":")+($az.webapp.deployment.pass)+("@")+($az.webapp.name)+(".scm.azurewebsites.net/")+($az.webapp.name)+(".git"));

		# Git Schema - Local
		$git.local.desc = "Web App - .NET Core";
		$git.local.parent_dir = (($Home)+("/git"));
		$git.local.reponame = ($git.remote.source.reponame);
		$git.local.work_tree = (($git.local.parent_dir)+("/")+($git.local.reponame));
	
	# Make sure the parent directory to the git-repo exists
	if ((Test-Path -Path ($git.local.parent_dir)) -eq $false) {
		Write-Host (("`nTask - Creating git parent-directory at `"")+($git.local.parent_dir)+("`""));
		New-Item -ItemType "Directory" -Path ($git.local.parent_dir);
	}

	# ------------------------------------------------------------- #

	$dotnet = @{};
	$dotnet.publish = @{};

	$dotnet.publish.reponame = ($git.local.reponame);
	
	$dotnet.publish.parent_abs = ($git.local.work_tree);

  $dotnet.publish.project_rel = ($az.secrets[$Vault_FrontendProject]);
  $dotnet.publish.angular_project_rel = ($az.secrets[$Vault_FrontendProject_Angular]);
	$dotnet.publish.project_abs = (($dotnet.publish.parent_abs)+("/")+($dotnet.publish.project_rel));

	$dotnet.publish.csproj_rel = (($dotnet.publish.project_rel)+("/")+($dotnet.publish.project_rel)+(".csproj"));
  $dotnet.publish.csproj_abs = (($dotnet.publish.parent_abs)+("/")+($dotnet.publish.csproj_rel));
  $dotnet.publish.angularproj_rel = (($dotnet.publish.project_rel)+("/")+($dotnet.publish.angular_project_rel));
	
	# $dotnet.publish.configuration = "Debug";
	# $dotnet.publish.configuration = "Production";

	$dotnet.publish.output = (($dotnet.publish.parent_abs)+("/published_")+(Get-Date -UFormat "%Y%m%d-%H%M%S"));

	# ------------------------------------------------------------- #

	###-- Configure the Web-App default build-path
	#
	#	az webapp config appsettings
	#		https://docs.microsoft.com/en-us/cli/azure/webapp/config/appsettings?view=azure-cli-latest
	#
	# Configurable settings
	#		https://github.com/projectkudu/kudu/wiki/Configurable-settings
	#
	# docs.microsoft.com - "To customize your deployment, include a .deployment file in the repository root"
	#		https://docs.microsoft.com/en-us/azure/app-service/deploy-local-git
	#

	$CommandDescription = (("Configuring [ Application Settings ] for Web-App `"")+($az.webapp.name)+("`""));
	Write-Host (("`n")+($CommandDescription)+("...`n"));
	
  $BuildSetting = (("baseUrl=https://bis-mc-20190322-1509-api.azurewebsites.net/api"));
	$ConfigWebapp = az webapp config appsettings set --name ($az.webapp.name) --resource-group ($az.resource_group) --subscription ($az.subscription) --settings ($BuildSetting) | ConvertFrom-Json;
	$last_exit_code += If($?){0}Else{1};

	$BuildSetting = ("MSDEPLOY_RENAME_LOCKED_FILES=1");
	$ConfigWebapp = az webapp config appsettings set --name ($az.webapp.name) --resource-group ($az.resource_group) --subscription ($az.subscription) --settings ($BuildSetting) | ConvertFrom-Json;
	$last_exit_code += If($?){0}Else{1};

	# Bomb-out on errors
	BombOut -NoAzLogout `
		-ExitCode ($last_exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-MessageOnSuccessJSON ($ConfigWebapp);

	# ------------------------------------------------------------- #

	# Git Pull from the Source-Repo
	
	# Build the username & token into one single url-request to pull from the git-repo with
	$git.remote.source.inline_creds_url = (("https://")+($az.secrets[$Vault_GitPullUser])+(":")+($az.secrets[$Vault_GitPullPass])+("@")+(($git.remote.source.url).Replace("https://","")));

	Set-Location -Path ($git.local.parent_dir);

	## Clone the Source-Repo
	$git.remote.destination.clone = `
	GitCloneRepo `
		-Url ($git.remote.source.inline_creds_url) `
		-LocalDirname ($git.local.parent_dir) `
		-SkipResolveUrl `
		-Quiet;
	
	# ------------------------------------------------------------- #

	$CommandDescription = ("Installing Windows Pre-Required DLL Runtimes");
	Write-Host (("`n")+($CommandDescription)+("...`n"));

	# HOTFIX - Install addtional required packages (required to be installed before dotnet publish runs)
	$dotnet.packages = @{};

	# Microsoft.AspNetCore
	$dotnet.packages["Microsoft.AspNetCore.Identity"] = "2.1.6";
	$dotnet.packages["Microsoft.AspNetCore.Identity.EntityFrameworkCore"] = "2.1.6";
	$dotnet.packages["Microsoft.AspNetCore.Identity.UI"] = "2.1.6";

	# Microsoft.Extensions
	$dotnet.packages["Microsoft.Extensions.Identity.Core"] = "2.1.6";
	$dotnet.packages["Microsoft.Extensions.Identity.Stores"] = "2.1.6";

	Set-Location -Path ($dotnet.publish.project_abs);
	ForEach ($RequiredPackage In (($dotnet.packages).GetEnumerator())) {
		
		ForEach ($EachMatchedDir In ((Get-ChildItem -Directory -Name -Path ($git.local.work_tree) -Include (($dotnet.publish.reponame)+("*"))).GetEnumerator())) {
			Set-Location -Path (($git.local.work_tree)+("/")+($EachMatchedDir));

			$CommandDescription = (("Installing: `"")+($RequiredPackage.Name)+(".dll`",  Version `"")+($RequiredPackage.Value)+("`" into `"")+($EachMatchedDir)+("`""));
			Write-Host ($CommandDescription);

			dotnet add package ($RequiredPackage.Name) --version ($RequiredPackage.Value) | Out-Null;

		}
	}


	$CommandDescription = (("Publishing `"")+($dotnet.publish.project_abs)+("`""));
	Write-Host (("`n")+($CommandDescription)+("...`n"));


	# HOTFIX - Rename Incorrectly-Capitalized Dirname
	# Set-Location -Path ($dotnet.publish.project_abs);
	# Rename-Item `
	# 	-Path (($dotnet.publish.parent_abs)+("/")+($dotnet.publish.reponame)+(".DTO")) `
	# 	-NewName (($dotnet.publish.reponame)+(".Dto"));


		# ------------------------------------------------------------- #
	
	# Push Codebase to Web-App (caught by the Kudu build server running in Azure Web-Apps)

	$PublishBeforePush = $true;

	Set-Location -Path ($git.local.work_tree);
	git config --global user.email ($az.account.show.user.name);
	git config --global user.name ($az.account.show.user.name);
		
	If ($PublishBeforePush -eq $true) {

		Set-Location -Path ($dotnet.publish.angularproj_rel);
		npm cache clean --force;
		# npm i -g npm;
		# Publish the Web-App
		Set-Location -Path ($dotnet.publish.parent_abs);

	# dotnet publish  <-- automatically performs dotnet restore & dotnet build, unless specified otherwise

		dotnet publish ($dotnet.publish.csproj_abs) --output ($dotnet.publish.output);
		# --framework ("netcoreapp2.1") `
		# --runtime ("win-x86") `

		# Setup Repo inside of the compiled code directory (push only those files)
		Set-Location -Path ($dotnet.publish.output);

		git init;
		git add .;
		git commit -m ($git.remote.destination.commit_msg);
		git remote add origin ($git.remote.destination.inline_creds_url);

		$CommandDescription = (("Pushing Compiled Code to Web-App `"")+($az.webapp.name)+("`"'s Kudu Build-Server"));
		Write-Host (("`n")+($CommandDescription)+("...`n"));

		git push origin master;

	} Else {

		$BuildSetting = (("PROJECT=")+($dotnet.publish.csproj_rel));
		$ConfigWebapp = az webapp config appsettings set --name ($az.webapp.name) --resource-group ($az.resource_group) --subscription ($az.subscription) --settings ($BuildSetting) | ConvertFrom-Json;
		$last_exit_code = If($?){0}Else{1};

		Set-Location -Path ($dotnet.publish.angularproj_rel);
		npm cache clean --force;
		npm i -g npm;
		# Redirect current code-repo so we can push to separate remote git-repo


		Set-Location -Path ($git.local.work_tree);
		
		git remote add ($git.remote.destination.ref_uid) ($git.remote.destination.inline_creds_url);
		git add -A;
		git commit -m ($git.remote.destination.commit_msg);

		$CommandDescription = (("Pushing Full Repo to Web-App `"")+($az.webapp.name)+("`"'s Kudu Build-Server"));
		Write-Host (("`n")+($CommandDescription)+("...`n"));
		
		git push ($git.remote.destination.ref_uid) ($git.remote.destination.branch);
		
	}

	# ------------------------------------------------------------- #


	# ------------------------------------------------------------- #

}

Export-ModuleMember -Function "Az_AppService_Frontend";