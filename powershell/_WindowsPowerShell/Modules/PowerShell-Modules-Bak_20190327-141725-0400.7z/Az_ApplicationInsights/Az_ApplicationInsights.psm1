function Az_ApplicationInsights {
  Param(

    #[Parameter(Mandatory=$true)]
    [String]$SubscriptionID = "BonEDGE-BIS",
        
    #[Parameter(Mandatory=$true)]
    [String]$ResourceGroup = "bis-sandbox-rg-redux",

    #[Parameter(Mandatory=$true)]
    [String]$AppServicePlan = "bis-20190311140634-appserviceplan",

    #[Parameter(Mandatory=$true)]
    [String]$Epithet = (("bis") + ("-") + (Get-Date -UFormat "%Y%m%d%H%M%S")),

    #[Parameter(Mandatory=$true)]
    [String]$Location = "eastus",

    #[Parameter(Mandatory=$true)]
    [String]$WebAppName = "bis-20190313190015-api",
        
    [Int]$ExitAfterSeconds = 600,

    [Switch]$RunLocalServer,
        
    [Switch]$Quiet

  )

  # Fail-out if any required modules are not found within the current scope
  $RequireModule = "BombOut"; 
  if (!(Get-Module ($RequireModule))) {
    # if (!(Get-Module -ListAvailable -Name ($RequireModule))) {
    Write-Host (("`n`nRequired Module not found: `"") + ($RequireModule) + ("`"`n`n"));
    Start-Sleep -Seconds 60;
    Exit 1;
  }
    
  $az = @{};
  $az.epithet = $Epithet;
  $az.webapp = @{};
  $az.webapp.name = $WebAppName;
  $az.webapp.resourceType = "Microsoft.Insights/components";
  $az.webapp.properties = ConvertTo-Json -InputObject ('{"serverFarmId": "/subscriptions/' + $SubscriptionID + '/resourceGroups/' + $ResourceGroup + '/providers/Microsoft.Web/serverfarms/' + $az.webapp.plan + '"}') -Depth 100;
  $az.webapp.location = $Location;
  
  $CommandDescription = (("Creating Application Insights for  `"") + ($az.webapp.name) + ("`""));
  Write-Host (("`n ") + ($CommandDescription) + (".....`n"));
  # Create Application Insights
  $az.webapp.appInsights = `
    az resource create `
    --name $az.webapp.name `
    --properties $az.webapp.properties `
    --resource-group $ResourceGroup `
    --subscription $SubscriptionID `
    --resource-type $az.webapp.resourceType `
    | ConvertFrom-Json;
  $az.webapp.exit_code = If ($?) {0}Else {1};

  BombOut `
    -ExitCode ($az.webapp.exit_code) `
    -MessageOnError (('Error thrown while [') + ($CommandDescription) + (']')) `
    -MessageOnSuccessJSON ($az.webapp.appInsights); 
  # ------------------------------------------------------------- #

  $instrumentationKey = "APPINSIGHTS_INSTRUMENTATIONKEY=" + $az.webapp.appInsights.properties.InstrumentationKey;
  # ------------------------------------------------------------- #

  $CommandDescription = (("Configuring App Instrumentation Key for  `"") + ($az.webapp.name) + ("`""));
  Write-Host (("`n ") + ($CommandDescription) + (".....`n"));
  # Create Application Insights settings to the API app
  $az.webapp.appSettings = `
    az webapp config appsettings set `
    --name $az.webapp.name `
    --resource-group $ResourceGroup `
    --subscription $SubscriptionID `
    --settings $instrumentationKey `
    | ConvertFrom-Json;
  $az.webapp.exit_code = If ($?) {0}Else {1};

  BombOut `
    -ExitCode ($az.webapp.exit_code) `
    -MessageOnError (('Error thrown while [') + ($CommandDescription) + (']')) `
    -MessageOnSuccessJSON ($az.webapp.appSettings); 

  $rt = @{};
  $rt.appInsightsCreate = $az.webapp.appInsights;
  $rt.appInsightsSet = $az.webapp.appSettings;

  Return $rt;

}

Export-ModuleMember -Function "Az_ApplicationInsights";