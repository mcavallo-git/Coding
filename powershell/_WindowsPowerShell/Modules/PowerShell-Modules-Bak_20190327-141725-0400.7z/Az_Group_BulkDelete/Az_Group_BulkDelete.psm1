#
#	Example use:
#
#		Az_Group_BulkDelete -StartingWith "bis-20190326"
#
function Az_Group_BulkDelete {
	Param(

		[Parameter(Mandatory=$true)]
		[String]$StartingWith,
		
		[Switch]$Quiet

	)
	
	## Mass-delete Resource Groups which share a common string in their name (to target resource groups created en-masse during testing/development)

	if ($StartingWith.length -gt 4) {

		$GroupsToDelete=@();

		# Walk through the list of resource groups
		$az_group_list = az group list | ConvertFrom-Json;
		For ($i=0; $i -lt $az_group_list.Count; $i++) {

			# Determine if the current Resource Group's name contains the user-defined string
			$Each_ResourceGroupName = (($az_group_list[$i]).name).ToLower();

			$DoNotDelete_ResourceGroupNames=@();
			$DoNotDelete_ResourceGroupNames += "bis-sandbox-rg-redux".ToLower();
			$DoNotDelete_ResourceGroupNames += "bis-static-resourcegroup".ToLower();
			$DoNotDelete_ResourceGroupNames += "bonedge-uat-rg".ToLower();
			$DoNotDelete_ResourceGroupNames += "bonedge-qa-rg".ToLower();
			$DoNotDelete_ResourceGroupNames += "bonedge-qa-gateway".ToLower();
			$DoNotDelete_ResourceGroupNames += "DefaultResourceGroup-EUS".ToLower();
			

			If (($DoNotDelete_ResourceGroupNames.Contains($Each_ResourceGroupName)) -eq $true) {

				Write-Host (("Skipping Resource Group (Permanent) '")+($Each_ResourceGroupName)+("'"));

			} ElseIf (($Each_ResourceGroupName.StartsWith($StartingWith)) -eq $true) {

				$GroupsToDelete += ($Each_ResourceGroupName);

			} ElseIf (!($PSBoundParameters.ContainsKey("Quiet"))) {
			
				Write-Host (("Skipping Resource Group (name doesn't start with given string) '")+($Each_ResourceGroupName)+("'"));

			}

		}

		# If any Matches were found
		If ($GroupsToDelete.Length -gt 0) {
			Write-Host "`n`n";

			ForEach ($EachRgToDelete In $GroupsToDelete) {
				Write-Host (("DELETE Resource Group  `"")+($EachRgToDelete)+("`""));
			}

			# Remove matching resource groups
			$confirmation = Read-Host (("`n       Are you sure? (y/n)"));

			If ($confirmation -eq 'y') {

				ForEach ($EachRgToDelete In $GroupsToDelete) {

					If (!($PSBoundParameters.ContainsKey("Quiet"))) { Write-Host (("Deleting resource group '")+($EachRgToDelete)+("'...")); }

					az group delete --name ($EachRgToDelete) --yes --no-wait;

				}
				

			} Else {

				If (!($PSBoundParameters.ContainsKey("Quiet"))) { Write-Host "No Action Taken"; }

			}

		}

		If (!($PSBoundParameters.ContainsKey("Quiet"))) {
			Write-Host "`n`n";
		}

	}

}

Export-ModuleMember -Function "Az_Group_BulkDelete";
