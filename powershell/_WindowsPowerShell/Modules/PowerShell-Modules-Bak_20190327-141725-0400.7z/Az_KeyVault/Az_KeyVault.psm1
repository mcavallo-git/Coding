function Az_KeyVault {
	Param(

		[Parameter(Mandatory=$true)]
		[String]$SubscriptionID,

		[Parameter(Mandatory=$true)]
		[String]$ResourceGroup,

		[Parameter(Mandatory=$true)]
		[String]$Name,

		[Parameter(Mandatory=$true)]
		[String]$ResourceAction,
		
		[String]$Location = "eastus",

		[String]$Suffix = "-keyvault",

		[String]$ResourceNameFull = (($Name) + ($Suffix)),
		
		[String]$ResourceDescription = "Azure Key Vault",
		
			[Switch]$ResourceNameAddTimestamp,
			
			[Switch]$PremiumSKU,

			[Switch]$Quiet
	)

	$ReturnValue = $false;

	# Fail-out if any required modules are not found within the current scope
	$RequireModule="BombOut";
	if (!(Get-Module ($RequireModule))) {
		Write-Host (("`n`nRequired Module not found: `"")+($RequireModule)+("`"`n`n"));
		Start-Sleep -Seconds 60;
		Exit 1;
	}
	
	# Optional - Concatenate a timestamp to end of the resource's name
	If (($PSBoundParameters.ContainsKey('ResourceNameAddTimestamp'))) {
		$ResourceNameFull += (("-")+(Get-Date -UFormat "%Y%m%d%H%M%S"));
	}
	
	if ($ResourceNameFull.length -gt 24) {
		$ResourceNameFull = $ResourceNameFull.Substring(0, 24);
	}

	$Sku = If($PSBoundParameters.ContainsKey("PremiumSKU")){"premium"} Else {"standard"};
	
	# $AzKeyVaultShow = `
	# 	az keyvault show `
	# 	--subscription ($SubscriptionID) `
	# 	--resource-group ($ResourceGroup) `
	# 	--name ($ResourceNameFull) `
	# 	| ConvertFrom-Json;
		
	## Attempt to Perform the Azure CLI Action
	Switch ($ResourceAction.ToUpper()) {

		## Create Resource:  Azure Key Vault
		"CREATE" {
			$CommandDescription = (("Creating ")+($ResourceDescription)+(" `"")+($ResourceNameFull)+("`""));
			If (!($PSBoundParameters.ContainsKey('Quiet'))) { Write-Host (("`n ")+($CommandDescription)+("...`n")); }
			###
			# az keyvault create `
			$AzKeyVaultCreate = `
				az keyvault create `
				--subscription ($SubscriptionID) `
				--resource-group ($ResourceGroup) `
				--name ($ResourceNameFull) `
				--location ($Location) `
				--sku ($Sku) `
				| ConvertFrom-Json;
			$AzKeyVaultCreate_ExitCode = If($?){0}Else{1};
			###
			BombOut `
				-ExitCode ($AzKeyVaultCreate_ExitCode) `
				-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
				-MessageOnSuccessJSON ($AzKeyVaultCreate);
			###
			$ReturnValue = $AzKeyVaultCreate;
			###
			break;
		}

		## Delete Resource:  Azure Key Vault
		"DELETE" {
			$CommandDescription = (("Deleting ")+($ResourceDescription)+(" `"")+($ResourceNameFull)+("`""));
			If (!($PSBoundParameters.ContainsKey('Quiet'))) { Write-Host (("`n ")+($CommandDescription)+("...`n")); }
			###
			# az keyvault delete `
			$AzKeyVaultDelete = `
				az keyvault delete `
				--subscription ($SubscriptionID) `
				--resource-group ($ResourceGroup) `
				--name ($ResourceNameFull) `
				| ConvertFrom-Json;
			$AzKeyVaultDelete_ExitCode = If($?){0}Else{1};
			###
			BombOut `
				-ExitCode ($AzKeyVaultDelete_ExitCode) `
				-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
				-MessageOnSuccessJSON ($AzKeyVaultDelete);
			###
			$ReturnValue = $AzKeyVaultDelete;
			###
			break;
		}

		default {
			###
			Write-Host (("`nInvalid selection for parameter `$ResourceAction: `"")+($ResourceAction)+("`" `n"));
			###
			$ReturnValue = $null;
			###
			break;
		}
	}

	Return $ReturnValue;

	# ------------------------------------------------------------- #
}

Export-ModuleMember -Function "Az_KeyVault";
