#
#	Example Call:
#		Az_Spinup -SubscriptionID "example_subscription_id" -CompanyName "example_company_name"
#
function Az_Spinup {
	Param(

		[Parameter(Mandatory=$true)]
		[String]$SubscriptionID,

		[String]$AzureLocation="eastus",
		# [String]$AzureLocation="East US",

		[Parameter(Mandatory=$true)]
		[String]$CompanyName,

		[Switch]$CompanyNameAddTimestamp,

		[Switch]$AllowUppercaseResourceNames,

		[Switch]$Quiet,

		[Int]$ExitAfterSeconds = 600
 
	)

	# ---------------------------------------------------------------------------------------------------------- #
	#
	##
	##  Microsoft Documentation, "Tutorial: Host a RESTful API with CORS in Azure App Service"
	##    - Reference: https://docs.microsoft.com/en-us/azure/app-service/app-service-web-tutorial-rest-api
	##
	##  Note that you may perform these actions in Azure's "Cloud Shell" by:
	##    - Logging into [ https://portal.azure.com ]
	##    - Selecting the " >_ " icon (~top middle of screen)
	##    - If presented with [ Choose terminal: "Bash" or "PowerShell" ] (etc.), select "PowerShell"
	##
	#
	# ---------------------------------------------------------------------------------------------------------- #
	
	$statics = @{};
	
	$statics.required = @{};

	$statics.required.commands = @{};
	$statics.required.commands.az = "https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?view=azure-cli-latest";
	$statics.required.commands.dotnet = "https://dotnet.microsoft.com/download/dotnet-core/2.1";
	$statics.required.commands.git = "https://git-scm.com/downloads";

	$statics.required.modules = @();
	$statics.required.modules += "BombOut";

	$statics.timestamp = (Get-Date -UFormat "%Y%m%d%H%M%S");

	$statics.url = @{};
	$statics.url.services = @{};
	$statics.url.services.azure = @{};
	$statics.url.services.azure.portal = 'https://portal.azure.com';
	$statics.url.documentation = @{};
	$statics.url.documentation.az_cli = ('https://docs.microsoft.com/en-us/cli/azure/reference-index?view=azure-cli-latest'); # General documentation on the "az" powershell command
	$statics.url.documentation.dotnet_cli = ('https://docs.microsoft.com/en-us/dotnet/core'); # General documentation on the "dotnet" powershell command
	$statics.url.documentation.this_script = ('https://docs.microsoft.com/en-us/azure/app-service/app-service-web-tutorial-rest-api'); # Guide that this script was based off-of
	$statics.url.documentation.local_https = ('https://docs.microsoft.com/en-us/aspnet/core/getting-started/?view=aspnetcore-2.2&tabs=windows'); # Web-Apps w/ HTTPS on Localhost

	$statics.dashes="----------------------------------------------------------------------------------------------------------";

	# Required Module(s)

	ForEach ($RequireModule In ($statics.required.modules)) {
		Write-Host (("Task - Checking for required module: `"")+($RequireModule)+("`"..."));
		If (Get-Module ($RequireModule)) {
			Write-Host (("Pass - Required Module exists: `"")+($RequireModule)+("`""));

		} Else {
			# Fail-out if any required modules are not found within the current scope
			Write-Host (("Fail - Required Module not found: `"")+($RequireModule)+("`""));
			Start-Sleep -Seconds 60;
			Exit 1;

		}
	}

	# ---------------------------------------------------------------------------------------------------------- #

	# Required Command(s)

	ForEach ($RequiredCommand In (($statics.required.commands).GetEnumerator())) {
		$CommandExists = EnsureCommandExists -Name ($RequiredCommand.Name) -OnErrorShowUrl ($RequiredCommand.Value);
	}
	
	# ---------------------------------------------------------------------------------------------------------- #
	#
	## Required: SubscriptionID
	#   |
	#   |--|> Must be specified as [ an in-line parameter ] or [ an environment variable ]
	#
	$SubscriptionID = If ($PSBoundParameters.ContainsKey("SubscriptionID")) {$SubscriptionID} ElseIf ($Env:SubscriptionID -ne $null) {$Env:SubscriptionID} Else {$null};

	$SubscriptionID_ExitCode = If ($SubscriptionID -ne $null) {0} Else {1};

	BombOut `
		-ExitCode ($SubscriptionID_ExitCode) `
		-MessageOnError ("Fail - Required variable `"SubscriptionID`" missing (must be specified as [ an in-line parameter ] or [ an environment variable ])") `
		-MessageOnSuccess ("Pass - Using subscription ID `"$SubscriptionID`"");

	# ---------------------------------------------------------------------------------------------------------- #
	#
	## Required: Company Name
	#

	$CompanyName = If ($PSBoundParameters.ContainsKey("CompanyName")) {$CompanyName} ElseIf ($Env:CompanyName -ne $null) {$Env:CompanyName} Else {$null};
	$last_exit_code = If ($CompanyName -ne $null) {0} Else {1};
	
	BombOut `
		-ExitCode ($last_exit_code) `
		-MessageOnError ("Fail - Required variable `"CompanyName`" missing (must be specified as [ an in-line parameter ] or [ an environment variable ])") `
		-MessageOnSuccess ("Pass - Using subscription ID `"$CompanyName`"");

	# Force lowercase resource names (by default)
	If (!($PSBoundParameters.ContainsKey('AllowUppercaseResourceNames'))) {
		$CompanyName = $CompanyName.ToLower();
	}

	# Optional - Concatenate a timestamp to end of the resource's name
	If (($PSBoundParameters.ContainsKey('CompanyNameAddTimestamp'))) {
		$CompanyShortName = If ($CompanyName.length -gt 9) { $CompanyName.Substring(0, 9) } Else { $CompanyName };
		$CompanyName = (($CompanyShortName)+("-")+(Get-Date -UFormat "%Y%m%d%H%M%S"));
	} Else {
		If ($CompanyName.length -gt 24) {
			$CompanyName = $ResourceNameFull.Substring(0, 24);
		}
	}

	# ---------------------------------------------------------------------------------------------------------- #

	$az = @{};

	$az.epithet = ($CompanyName);

	$az.subscription = ($SubscriptionID);
	
	$az.location = ($AzureLocation);

	## Login to Azure via CLI
	$az.login = @{};

	## Subscription Information
	$az.account = @{};
	$az.account.list = @{};  ## Filled-in by:  [ az account list ]
	$az.account.show = @{};  ## Filled-in by:  [ az account show ]

	## Keyvaults
	$az.keyvault = @{};
	$az.keyvault.git = @{};
	$az.keyvault.sql = @{};

	## Keyvault Secrets
	$az.secrets = @{};

	$az.secrets.git = @{};
	$az.secrets.git.vault = "bis-static-keyvault";
	$az.secrets.git.clone_url_https = "git-pull-url-https";
	$az.secrets.git.clone_url_ssh = "git-pull-url-ssh";
	$az.secrets.git.branch = "git-pull-branch";
	$az.secrets.git.username = "git-pull-user";
	$az.secrets.git.usertoken = "git-pull-token";
	$az.secrets.git.project_https_port = "webapp-dotnet-https-port";
	$az.secrets.git.buildpath_backend_dotnet = "webapp-backend-project";
	$az.secrets.git.buildpath_frontend_dotnet = "webapp-frontend-project";
	$az.secrets.git.buildpath_frontend_angular = "git-webapp-buildpath-frontend-angular";

	$az.secrets.sql = @{};
	$az.secrets.sql.vault = "bis-static-keyvault";
	$az.secrets.sql.admin_user = "sql-adminuser";
	$az.secrets.sql.admin_pass = "sql-adminpass";

	## Resource group
	$az.group = @{};
	$az.group.name = (($az.epithet) + ("-resource-group"));
	$az.group.create = @{};

	## App Service plans
	$az.appservice = @{};
	$az.appservice.desc = 'App Service Plan';
	$az.appservice.plan = @{};
	$az.appservice.plan.name = (($az.epithet) + ("-appservice-plan"));
	$az.appservice.plan.resource_group = ($az.group.name);
	$az.appservice.plan.sku = "FREE";
	$az.appservice.plan.create = @{}; ## Filled-in by:  [ az appservice plan create ... ]

	
	$az.sql = @{};
	$az.sql.server = @{}; ## SQL Server
	$az.sql.database = @{}; ## SQL Database

	## Web apps
	$az.webapp = @{};
	$az.webapp.desc = 'Web App';
	$az.webapp.create = @{};
	$az.webapp.create.backend = @{};
	$az.webapp.create.frontend = @{};
	$az.webapp.resource_group = ($az.group.name);
	$az.webapp.plan = ($az.appservice.plan.name);
	$az.webapp.name = (($az.epithet) + ("-webapp"));
	$az.webapp.url = (("https://") + ($az.webapp.name) + (".azurewebsites.net"));
	$az.webapp.service = @{};
	$az.webapp.service.swagger = (($az.webapp.url) + ("/swagger"));
	$az.webapp.api = @{};
	$az.webapp.api.swagger = (($az.webapp.url) + ("/swagger/v1/swagger.json"));
	$az.webapp.api.todo = (($az.webapp.url) + ("/api/todo"));

	## Web app deployments (backend user credentials/token)
	$az.webapp.deployment = @{};
	$az.webapp.deployment.desc = "Git Deployment Credentials";
	$az.webapp.deployment.user = @{};  ## Filled-in by:  [ az webapp deployment user ... ]
	$az.webapp.deployment.user_name = (("bnl-")+(([Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes((Get-Random -SetSeed (Get-Random))))).Substring(0,20)));
	# Wait for a random amount of time so that we increase the millisecond gap between user & password string-generation (expert mode guessing)
	Start-Sleep -Milliseconds (Get-Random -Minimum (Get-Random -Minimum 50 -Maximum 499) -Maximum (Get-Random -Minimum 500 -Maximum 949));
	$az.webapp.deployment.user_pass = ((([Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes(("PASS!")+(Get-Random -SetSeed (Get-Random))))).Substring(0,20))+("aA1!"));

	# ---------------------------------------------------------------------------------------------------------- #

	#  Get current subscription info, etc.
	$CommandDescription = "Requesting Subscription Information";
	Write-Host (("`n")+($CommandDescription)+("...`n"));

	$az.account.show = `
		az account show `
		| ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};

	If ($last_exit_code -ne 0) {

		# If the account details throws an error for the first time, then request Azure user-credentials to be entered
		$CommandDescription = "Performing User Authentication/Authorization";
		Write-Host (("`n")+($CommandDescription)+("...`n"));

		$az.login = `
			az login `
			| ConvertFrom-Json;
		$last_exit_code = $?;

		# Bomb-out on errors
		BombOut `
			-ExitCode ($last_exit_code) `
			-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
			-MessageOnSuccessJSON ($az.account.show);

		# Re-acquire Subscription info
		$CommandDescription = (("Requesting ")+($az.account.desc));
		Write-Host (("`n")+($CommandDescription)+("...`n"));

		$az.account.show = `
			az account show `
			| ConvertFrom-Json;
		$last_exit_code = If($?){0}Else{1};

	}

	# Bomb-out on errors
	BombOut `
		-ExitCode ($last_exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-MessageOnSuccess ("Azure credentials validated") `
		-MessageOnSuccessJSON ($az.account.show);

	# ---------------------------------------------------------------------------------------------------------- #

	$az.account.list = `
		az account list `
		| ConvertFrom-Json;
	
	# ---------------------------------------------------------------------------------------------------------- #

	# 1 Create Resource Group

	$CommandDescription = "Creating Resource Group";
	Write-Host (("`n")+($CommandDescription)+("...`n"));

	$az.group.create = `
		az group create `
			--name ($az.group.name) `
			--location ($az.location) `
			--subscription ($az.subscription) `
		| ConvertFrom-Json;
	$last_exit_code = If($?){0}Else{1};

	# Bomb-out on errors
	BombOut `
		-ExitCode ($last_exit_code) `
		-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
		-MessageOnSuccessJSON ($az.group.create) `
	;

	# ---------------------------------------------------------------------------------------------------------- #


	# 2 Create Keyvault

	# ---------------------------------------------------------------------------------------------------------- #

	# 2.1 Whitelist current CIDR on the SQL Keyvault's Firewall
	$Loopback_CIDR = `
		ResolveIPv4 `
			-GetLoopbackAddress `
			-OutputNotation "CIDR";

	$az.keyvault.sql.network_rule_list = `
		az keyvault network-rule list `
			--name ($az.secrets.sql.vault) `
			| ConvertFrom-Json `
	;
	
	$Loopback_CIDR_AlreadyWhitelisted = $false;

	ForEach ($EachCIDR_WhitelistObj In (($az.keyvault.sql.network_rule_list).ipRules)) {
		If ($Loopback_CIDR -eq $EachCIDR_WhitelistObj.value) {
			$CIDR_AlreadyWhitelisted = $true;
		}
	}

	If ($CIDR_AlreadyWhitelisted -eq $true) {
			
		Write-Host (("Skip - Current CIDR `"")+($Loopback_CIDR)+("`" is already allowed through the firewall on KeyVault `"")+($az.secrets.sql.vault)+("`""));

	} Else {

		$CommandDescription = (("Whitelisting current-loopback CIDR `"")+($Loopback_CIDR)+("`" through the firewall on KeyVault `"")+($az.secrets.sql.vault)+("`""));
		Write-Host (("`n")+($CommandDescription)+("...`n"));

		$az.keyvault.sql.allow_current_ipv4 = `
		az keyvault network-rule add `
			--name ($az.secrets.sql.vault) `
			--ip-address ($Loopback_CIDR) `
			| ConvertFrom-Json;
		$last_exit_code = If($?){0}Else{1};

		# Bomb-out on errors
		BombOut -NoAzLogout `
			-ExitCode ($last_exit_code) `
			-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
			-MessageOnSuccessJSON ($az.keyvault.allow_current_ipv4);

	}

	# ---------------------------------------------------------------------------------------------------------- #

	# Skip the next whitelisting step if the Git Keyvault is identical to the SQL Keyvault
	If ($az.secrets.git.vault -ne $az.secrets.sql.vault) {
			
		# 2.2 Whitelist current CIDR on the Git Keyvault's Firewall
		$Loopback_CIDR = ResolveIPv4 -GetLoopbackAddress;

		$az.keyvault.git.network_rule_list = `
			az keyvault network-rule list `
				--name ($az.secrets.git.vault) `
				| ConvertFrom-Json `
		;

		$Loopback_CIDR_AlreadyWhitelisted = $false;
			
		ForEach ($EachCIDR_WhitelistObj In (($az.keyvault.git.network_rule_list).ipRules)) {
			If ($Loopback_CIDR -eq $EachCIDR_WhitelistObj.value) {
				$CIDR_AlreadyWhitelisted = $true;
			}
		}

		If ($CIDR_AlreadyWhitelisted -eq $true) {
				
			Write-Host (("Skip - Current CIDR `"")+($Loopback_CIDR)+("`" is already allowed through the firewall on KeyVault `"")+($az.secrets.git.vault)+("`""));

		} Else {

			$CommandDescription = (("Whitelisting current-loopback CIDR `"")+($Loopback_CIDR)+("`" through the firewall on KeyVault `"")+($az.secrets.git.vault)+("`""));
			Write-Host (("`n")+($CommandDescription)+("...`n"));

			$az.keyvault.git.allow_current_ipv4 = `
			az keyvault network-rule add `
				--name ($az.secrets.git.vault) `
				--ip-address ($Loopback_CIDR) `
				| ConvertFrom-Json;
			$last_exit_code = If($?){0}Else{1};

			# Bomb-out on errors
			BombOut -NoAzLogout `
				-ExitCode ($last_exit_code) `
				-MessageOnError (('Error thrown while [')+($CommandDescription)+(']')) `
				-MessageOnSuccessJSON ($az.keyvault.allow_current_ipv4);

		}

	}
	# 3	Create Secret:  sql-adminuser
	# $az.sqldb.adminuser = (((az keyvault secret show --subscription ("xxyyzz-sub") --vault-name ("xxyyzz-vault") --name ("xxyyzz-user"))	| ConvertFrom-Json).value);

	# 4	Create Secret:  sql-adminpass
	# $az.sqldb.adminpass = (((az keyvault secret show --subscription ("xxyyzz-sub") --vault-name ("xxyyzz-vault") --name ("xxyyzz-pass"))	| ConvertFrom-Json).value);

	# ---------------------------------------------------------------------------------------------------------- #

	# 5 Create SQL Server (Firewall Included)
	# 6 Create SQL Database
	Write-Host "`n`n";	Write-Host $statics.dashes; Write-Host "Calling:   Az_CreateSqlDb `n";
	$Az_CreateSqlDb = `
		Az_CreateSqlDb `
			-SubscriptionID ($az.subscription) `
			-ResourceGroup ($az.group.name) `
			-Epithet ($az.epithet) `
		;

	$az.sql.server = $Az_CreateSqlDb.server;
	$az.sql.database = $Az_CreateSqlDb.database;

	# ---------------------------------------------------------------------------------------------------------- #

	# 7 Create App-Service Plan
	Write-Host "`n`n"; Write-Host $statics.dashes; Write-Host "Calling:   Az_CreateAppServicePlan `n";
	$az.appservice.plan = `
		Az_CreateAppServicePlan `
			-SubscriptionID ($az.subscription) `
			-ResourceGroup ($az.group.name) `
			-Epithet ($az.epithet) `
		;

	# ---------------------------------------------------------------------------------------------------------- #

	# 8 Create App-Service, Back-End (Firewall Included)
	Write-Host "`n`n"; Write-Host $statics.dashes; Write-Host "Calling:   Az_AppService_Backend `n";
	$az.webapp.create.backend = `
		Az_AppService_Backend `
			-SubscriptionID ($az.subscription) `
			-ResourceGroup ($az.group.name) `
			-AppServicePlanName ($az.appservice.plan.name) `
			-Epithet ($az.epithet) `
			-KeyVault_Git ($az.secrets.git.vault) `
			-Vault_GitPullUrl443 ($az.secrets.git.clone_url_https) `
			-Vault_GitPullUrl22 ($az.secrets.git.clone_url_ssh) `
			-Vault_GitBranch ($az.secrets.git.branch) `
			-Vault_GitPullUser ($az.secrets.git.username) `
			-Vault_GitPullPass ($az.secrets.git.usertoken) `
			-Vault_WebAppPortHttps ($az.secrets.git.project_https_port) `
			-Vault_BackendProject ($az.secrets.git.buildpath_backend_dotnet) `
			-KeyVault_Sql ($az.secrets.sql.vault) `
			-Vault_SqlUser ($az.secrets.sql.admin_user) `
			-Vault_SqlPass ($az.secrets.sql.admin_pass) `
		;

	# ---------------------------------------------------------------------------------------------------------- #
	# 9 Create App-Service, Front-End (Firewall Included)
	Write-Host "`n`n"; Write-Host $statics.dashes; Write-Host "Calling:   Az_AppService_Frontend `n";
	$az.webapp.create.frontend = `
		Az_AppService_Frontend `
			-SubscriptionID ($az.subscription) `
			-ResourceGroup ($az.group.name) `
			-AppServicePlanName ($az.appservice.plan.name) `
			-Epithet ($az.epithet) `
			-KeyVault_Git ($az.secrets.git.vault) `
			-Vault_GitPullUrl443 ($az.secrets.git.clone_url_https) `
			-Vault_GitPullUrl22 ($az.secrets.git.clone_url_ssh) `
			-Vault_GitBranch ($az.secrets.git.branch) `
			-Vault_GitPullUser ($az.secrets.git.username) `
			-Vault_GitPullPass ($az.secrets.git.usertoken) `
			-Vault_WebAppPortHttps ($az.secrets.git.project_https_port) `
			-Vault_FrontendProject ($az.secrets.git.buildpath_frontend_dotnet) `
			-Vault_FrontendProject_Angular ($az.secrets.git.buildpath_frontend_angular) `
		;

	# ---------------------------------------------------------------------------------------------------------- #

	# 10 Create Api Management Service, which handles request throughput for both App-Services



	# ---------------------------------------------------------------------------------------------------------- #

	# 11 Create Application Insights, which log/monitor both App-Services



	# ---------------------------------------------------------------------------------------------------------- #

}

Export-ModuleMember -Function "Az_Spinup";
