
function BombOut {
	Param(

		[Parameter(Mandatory=$true)]
		[Int]$ExitCode,

		[String]$MessageOnError,

		$MessageOnErrorJSON,

		[String]$MessageOnSuccess,
		
		$MessageOnSuccessJSON,

		[Int]$ExitAfterSeconds = 600,

		[Switch]$NoAzLogout,
		
		[Switch]$AzLogoutOnErrors,
		
		[Switch]$Quiet

	)

	If ($ExitCode -ne 0) {
		# Errors Exist - Bomb-out
		If ($PSBoundParameters.ContainsKey('MessageOnError')) {
			Write-Host (("`n`n")+($MessageOnError));
		}
		
		If ($PSBoundParameters.ContainsKey('MessageOnErrorJSON')) {
			$ErrorStringFromJSON = [PSCustomObject]$MessageOnErrorJSON | Out-String;
			Write-Host $ErrorStringFromJSON -ForegroundColor red;
		}

		# On Error - Logout from Azure
		If ($PSBoundParameters.ContainsKey('AzLogoutOnErrors')) {

			Write-Host (("`n`nFail - Clearing azure session via [ az account clear --verbose ]..."));
			az account clear --verbose;
			
		} Else {

			If (!($PSBoundParameters.ContainsKey('Quiet'))) {
				Write-Host (("`n`nSkip - Clearing azure session (called with -NoAzLogout)"));
			}

		}

		Write-Host (("`n`nFail - Exiting after ")+($ExitAfterSeconds)+(" seconds..."));
		Start-Sleep -Seconds ($ExitAfterSeconds);
		Exit;

	} Else {

		# Success! No errors found
		If ($PSBoundParameters.ContainsKey('MessageOnSuccess')) {
			If (!($PSBoundParameters.ContainsKey('Quiet'))) { Write-Host ($MessageOnSuccess); }
		}

		If ($PSBoundParameters.ContainsKey('MessageOnSuccessJSON')) {
			If (!($PSBoundParameters.ContainsKey('Quiet'))) {
				$SuccessStringFromJSON = [PSCustomObject]$MessageOnSuccessJSON | Out-String;
				Write-Host $SuccessStringFromJSON -ForegroundColor green;
			}
		}

	}

}

Export-ModuleMember -Function "BombOut";
