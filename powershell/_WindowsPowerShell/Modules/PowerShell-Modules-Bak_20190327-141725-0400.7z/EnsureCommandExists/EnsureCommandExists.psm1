function EnsureCommandExists {
	Param(
		
		[Parameter(Mandatory=$true)]
		[String]$Name,

		[Switch]$Quiet,

		[String]$OnErrorShowUrl="",

		[Switch]$ContinueOnErrors

	)

	If (!($PSBoundParameters.ContainsKey('Quiet'))) { Write-Host (("Task - Checking for local command: ") + ($Name)); }


	$Revertable_ErrorActionPreference = $ErrorActionPreference; $ErrorActionPreference = 'SilentlyContinue';
	$GetCommand = (Get-Command $Name);
	$ErrorActionPreference = $Revertable_ErrorActionPreference;

	$CommandExists = If($GetCommand -eq $null){0}Else{1};

	If ($CommandExists -eq 1) {
		# Pass - Command Exists
		
		$CommandVersion = [System.String]::Join(".",($GetCommand.Version));
		
		If (!($PSBoundParameters.ContainsKey('Quiet'))) { Write-Host (("Pass - Command exists: ") + ($Name) + (" (v") + ($CommandVersion) + (")")); }

	} Else {
		#Fail - Command not found


		$ErrorMessage = (("Fail - Command not found: ") + ($Name));

		If ($PSBoundParameters.ContainsKey('OnErrorShowUrl')) {

			# Download/Show-Info via URL
			If (!($PSBoundParameters.ContainsKey('Quiet'))) { Write-Host (("Info - For troubleshooting, download references, etc. please visit Url: ")+($OnErrorShowUrl)); }

			Start ($OnErrorShowUrl);

		}

		If (!($PSBoundParameters.ContainsKey('ContinueOnErrors'))) {

			# Do not continue on errors - Exit now
			BombOut `
			-ExitCode 1 `
			-MessageOnError ($ErrorMessage) `
			-MessageOnSuccess ("");

		}

	}

	Return $CommandExists;
}

Export-ModuleMember -Function "EnsureCommandExists";
