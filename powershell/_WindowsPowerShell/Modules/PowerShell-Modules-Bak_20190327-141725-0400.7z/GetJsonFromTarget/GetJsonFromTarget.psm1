function GetJsonFromTarget {
	Param(

		[Parameter(Mandatory=$true)]
		[String]$target,

		[Switch]$Quiet

	)

	If (!($PSBoundParameters.ContainsKey('Quiet'))) {
		Write-Host (("`n`n`n"));
	}

	$json = @{};
	# $json.dirname = $PSScriptRoot;
	$json.dirname = $Env:UserProfile;
	$json.basename = "az_config.json";
	$json.fullpath = (($json.dirname) + ("/") + ($json.basename));

	$json.exists = Test-Path -Path ($json.fullpath);

	If ($json.exists -eq $false) {
		If (!($PSBoundParameters.ContainsKey('Quiet'))) {
			Write-Host (("`nFail - Target not found: `"") + ($json.fullpath) + ("`"`n"));
			Start-Sleep -Seconds 60;
		}
		Exit;

	} Else {
		If (!($PSBoundParameters.ContainsKey('Quiet'))) {
			Write-Host (("`nPass - Target exists: `"") + ($json.fullpath) + ("`"`n"));
		}
	}

	$json.data = Get-Content -Raw -Path ($json.fullpath) | ConvertFrom-Json;

	If (!($PSBoundParameters.ContainsKey('Quiet'))) {
		[PSCustomObject]$json;
		Write-Host (("`n`n`n"));
	}

	Return $json;
}

Export-ModuleMember -Function "GetJsonFromTarget";

# Import-Module (".../GetJsonFromTarget.psm1");

# Get-Module "GetJsonFromTarget";

